package DocumentManaging;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;

public class Utilities {

	public static final void main(String[] args) throws IOException {
		System.out.println(getSearchQuery("Far seas"));
		dataForAllRegions();
		heatMapData("Total", 3);
	}
	
	
	public static void heatMapData(String category, int num) throws IOException {
		File file = new File("/home/jeremy/China/webscraping/data.csv");
		BufferedReader bf = new BufferedReader(new FileReader(file));
		HashMap<String,HashMap<String,double[][]>> data = new HashMap<>();
		while(bf.ready()) {
			String[] line = bf.readLine().split(",");
			int yr = Integer.parseInt(line[0]);
			String region = line[1];
			
			String cat = "";
			double count = 0;
			double total = 0;
			for(int i = 2; i < line.length; i++) {
				if((i-2) % 3 == 0) {
					cat = line[i];

					HashMap<String,double[][]> regionData = new HashMap<>();
					if(data.containsKey(cat)) {
						regionData = data.get(cat);
					}  else {
						data.put(cat, regionData);
					}
					cat = line[i];

				} else if((i-2) % 3 == 1){
					count = Double.parseDouble(line[i]);
				} else if((i-2)%3 == 2) {
					total = count / Double.parseDouble(line[i]);
					if(Double.parseDouble(line[i]) == 0) {
						total = 1;
					}
					HashMap<String,double[][]> regionData =  data.get(cat);
					double[][] dd = new double[2][19];
					if(regionData.containsKey(region)) {
						dd = regionData.get(region);
					}
					dd[0][yr] = count;
					dd[1][yr] = total;
					regionData.put(region, dd);
					data.put(cat, regionData);
					
				}
			}
		}
		
		double max = 0;
		HashMap<String, double[]> regions = new HashMap<>();
		for(String region : data.get(category).keySet()) {
			double[][] regionData = data.get(category).get(region);
			double[] d = new double[4];
			int j = 0;
			double tot = 0;
			double count = 0;
			
			System.out.println(Arrays.deepToString(regionData));
			for(int i = 2; i < regionData[0].length;i++) {
				
				if((i-2)%4==0) {
					
					if(j >= 1) {
						d[j-1] = count/tot;
						if(d[j-1] > max) {
							max = d[j-1];
						}
						count = 0;
						tot = 0;
					}
					j++;

				} 
				count += regionData[0][i];
				tot += regionData [1][i];
			}
			System.out.println(Arrays.toString(d));
			regions.put(region, d);
		}
		for(String r : regions.keySet()) {
			double[] d = regions.get(r);
			for(int i = 0; i < d.length; i++) {
				d[i] /= max;
			}
			System.out.println(returnRegion(r,d[num]));
		}
		bf.close();

	}
	private static String returnRegion(String r, double dd) {
		int d  = (int) (dd*100);
		if(r.equals("Northern")) {
			return " Beijing: " + d +"\n Tianjin: " + d +"\n Hebei: " + d +"\n Shanxi: " + d +"\n Inner Mongolia: " + d ;
		} else if(r.equals("Northeastern")) {
			return " Liaoning: " + d +"\n Jilin: " + d +"\n Heilongjiang: " + d ;
		} else if (r.equals("East")) {
			return " Shanghai: " + d +"\n Jiangsu: " + d +"\n Zhejiang: " + d + "\n Anhui: " + d + "\n Fujian: " + d + "\n Jiangxi: " + d + "\n Shandong: " + d;
		} else if (r.equals("Southern")) {
			return " Henan: " + d +"\n Hubei: " + d +"\n Hunan: " + d + "\n Gunagdong: " + d + "\n Guangxi: " + d + "\n Hainan: " + d;
		} else if (r.equals("Southwest")) {
			return " Chongqing: " + d +"\n Sichuan: " + d +"\n Guizhou: " + d + "\n Yunnan: " + d + "\n Tibet: " + d;
		} else if (r.equals("Northwestern")) {
			return " Shaanxi: " + d +"\n Gansu: " + d +"\n Qinghai: " + d + "\n Ningxia: " + d + "\n Xinjiang: " + d;
		} else {
			return "";
		}
	}


	public static void dataForAllRegions() throws IOException {
		File folder = new File("/home/jeremy/China/webscraping");
		File out = new File("/home/jeremy/China/webscraping/data.csv");
		String ret = "";

		PrintWriter pw = new PrintWriter(new FileWriter(out));
		for(File region : folder.listFiles()) {
			String reg = region.getName();
			if(reg.contains("ipynb")) {
				continue;
			}
			if(region.isDirectory()) {
				ret += createRegionalLongitudinalCSVs(reg);

			}
		}
		pw.print(ret);
		pw.close();
	}
	public static String createRegionalLongitudinalCSVs(String region) throws IOException {
		File folder = new File("/home/jeremy/China/webscraping/" + region);
		
		File[] files = folder.listFiles();
		HashMap<String,double[]> cats = new HashMap<>();
		double[] norms = new double[19];
		for(int i = 0; i < norms.length; i++) {
			norms[i] = 1;
		}
		
		for(File f : files) {
			
				if(!f.isDirectory()) {
					continue;
				}
				for(File f2 : f.listFiles()) {
					if(f.getName().equals("norm.csv")) {
						BufferedReader bf = new BufferedReader(new FileReader(f));
						while(bf.ready()) {
							String[] str = bf.readLine().split(",");
							int yr = Integer.parseInt(str[0]);
							int count = Integer.parseInt(str[0]);
							norms[yr] = count;
						}
						bf.close();	
					} 
					
					String cat = f2.getName().replaceAll("\\.csv", "").replaceAll("[0-9]", "");
					if(cat.contains("lock")) {
						continue;
					}
					switch(cat) {
							case "nearseasgeo": cat = "Near Seas Geographical Features";
							break;
							case "nearseas": cat = "Near Seas";
							break;
							case "farseas": cat = "Far Seas";
							break;
							case "theory": cat = "Military Policies or Theories";
							break;
							case "farseasgeo" : cat = "Far Seas Geographical Features";
							break;
							case "law": cat = "International naval law";
							break;
							case "technology": cat = "Naval technology";
							break;
							case "security": cat = "Maritime security interests";
							break;
							case "incidents": cat = "International incidents";
							break;
							case "foreign": cat = "Foreign navies";
							break;
					}
					BufferedReader bf = new BufferedReader(new FileReader(f2));
					int i = 0;
					double[] counts = new double[19];

					
					if(cats.containsKey(cat)) {
						counts = cats.get(cat);
					} else {
						cats.put(cat,counts);
					}
					int  yr = 0;
					while(bf.ready()) {
						i++;
						String line = bf.readLine();
						if(line.contains("Date Range")) {
							yr = Integer.parseInt(line.split(",")[1].split("-")[0])-2000;
						}
						if(line.contains("'")) {
							String[] l = line.split(",");
							yr = Integer.parseInt(l[2].split("'")[1]);
							int count = Integer.parseInt(l[3]);
							counts[yr] += count;
						} else if(line.contains("/")) {
							String[] l = line.split(",");
							int count = Integer.parseInt(l[3]);
							counts[yr] += count;
						}
					}
					
					cats.put(cat, counts);
					bf.close();
					
					
				}	
				
			
		}
		if(!cats.isEmpty() && cats.containsKey("norm")) {
			norms = cats.get("norm");
			for(int i = 0; i < norms.length; i++) {
				norms[i] += 1;
			}
		}
		
		String ret = "";
		for(int i = 0; i < 19; i++) {
			int sum = 0;

			
			String line = "";
			line += i + ",";
			line += region + ",";
			for(String cat : cats.keySet()) {
				if(cat.equals("norm")) {
					continue;
				}
				double[] cnt = cats.get(cat);
				double count = cnt[i];
				sum += count;
				line += cat + ",";				
				line += count + ",";
				line += count/norms[i] + ",";
			}
			line += "Total,";
			line += sum + "," + sum/norms[i];
			ret += line + "\n"; 
		}
		
		return ret;
	}
	/*
	 * Returns the boolean search query for a given category
	 */
	public static String getSearchQuery(String cat) throws IOException {
		String fileName = "/home/jeremy/China/categorized.csv";
		String ret = "";
		BufferedReader bf = new BufferedReader( new InputStreamReader(new FileInputStream(fileName), "utf-16"));
		String str  = bf.readLine();
		String eng="";
		
		String[] cats = str.split(",");
		String navy = "\"海军\"";
		
		ret = navy +" AND " + "(";
		while(bf.ready()) {
			String[] ins = bf.readLine().split(",");
			for(int i = 0; i < ins.length; i++) {
				if(cats[i].equals(cat)) {
					for(String s : ins[i].split("@")) {
						if(s.isEmpty()) {
							continue;
						}
						if(s.matches(".*?[a-z].*?")) {
							eng += "\"" + s.replaceAll("\"", "").trim() + "\" OR ";
							continue;
						}
						ret += "\"" + s.replaceAll("\"", "").trim() + "\" OR ";
					}
				}
			}
		}
		
		
		return ret.substring(0, ret.lastIndexOf(" OR")) + ")" +"\n" + eng.substring(0, eng.lastIndexOf(" OR")) + ")";
		
		
	}
}
